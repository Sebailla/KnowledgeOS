declare module "node:test" {
  type TestFunction = (
    name: string,
    fn: () => void | Promise<void>,
  ) => void;

  const test: TestFunction;
  export default test;
}

declare module "node:assert/strict" {
  interface Assert {
    equal(
      actual: unknown,
      expected: unknown,
    ): void;
    deepEqual(
      actual: unknown,
      expected: unknown,
    ): void;
    rejects(
      block: () => Promise<unknown>,
      error?: new (...args: never[]) => Error,
    ): Promise<void>;
  }

  const assert: Assert;
  export default assert;
}
