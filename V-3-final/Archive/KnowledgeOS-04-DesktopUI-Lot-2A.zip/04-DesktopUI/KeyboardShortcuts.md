# Desktop Application Keyboard Shortcuts

**Project:** KnowledgeOS

**Section:** Implementation

**Module:** Desktop Application

**Layer:** Desktop UI

**Version:** 1.0

**Status:** Approved

**Architecture Baseline:** KnowledgeOS Architecture V3

**Author:** KnowledgeOS Team

---


# 1. Purpose

This document defines the authoritative keyboard-shortcut architecture for the KnowledgeOS Desktop Application.

It specifies registration, scoping, resolution, conflict management, customization, plugin participation and translation of shortcut invocations into Commands.

# 2. Scope

This document governs:

- shortcut definitions;
- key combinations;
- shortcut scopes;
- context resolution;
- conflict detection;
- user customization;
- plugin shortcuts;
- command dispatch;
- discoverability;
- accessibility;
- diagnostics and testing.

# 3. Objectives

The shortcut system shall:

- provide deterministic resolution;
- preserve macOS conventions;
- support keyboard-first workflows;
- expose conflicts before activation;
- support contextual shortcuts;
- support user-defined keymaps;
- integrate plugins safely;
- remain independent from native control instances.

# 4. Architectural Position

```text
Native Key Event
       |
       v
Input Handling
       |
       v
Shortcut Resolver
       |
       v
Command Binding
       |
       v
Command Bus
```

# 5. Shortcut Definition

A shortcut definition contains:

- stable shortcut identity;
- command identity;
- key combination;
- scope;
- context predicate;
- priority;
- source;
- localization metadata;
- discoverability metadata;
- customization policy.

# 6. Stable Identity

Shortcut identity shall remain stable across versions whenever semantic behavior remains the same.

User overrides shall bind to stable shortcut identity, not display labels.

# 7. Key Combination

A key combination may contain:

- primary key;
- Command modifier;
- Option modifier;
- Control modifier;
- Shift modifier;
- function-key metadata;
- physical or semantic interpretation policy.

macOS conventions shall be preferred.

# 8. Reserved Shortcuts

System-reserved shortcuts shall not be overridden.

The implementation shall maintain a platform-aware reserved shortcut registry.

# 9. Shortcut Scopes

Supported scopes are:

1. application;
2. Workspace;
3. Window;
4. editor;
5. panel;
6. focused component;
7. modal scope.

More specific active scopes normally take precedence over broader scopes.

# 10. Scope Activation

A scope is active only when its logical context is active.

Examples:

- editor scope requires an active editor;
- panel scope requires that panel to own the relevant focus context;
- modal scope requires the corresponding modal surface;
- Workspace scope requires an active Workspace.

# 11. Context Predicates

A shortcut may declare a context predicate based on immutable UI projections.

Predicates may inspect:

- active editor type;
- selection type;
- focus role;
- command availability;
- modal state;
- plugin capability;
- read-only state.

Predicates shall not perform business logic.

# 12. Resolution Order

Shortcut resolution follows:

1. normalize key event;
2. preserve native text-input requirements;
3. identify active scopes;
4. collect matching definitions;
5. evaluate context predicates;
6. remove unavailable Commands;
7. apply priority and specificity;
8. resolve conflicts;
9. dispatch the selected Command.

# 13. Specificity

When two shortcuts use the same combination, the most specific valid scope wins unless an explicit higher-priority platform rule applies.

Specificity order is:

```text
Modal
Focused Component
Panel
Editor
Window
Workspace
Application
```

# 14. Priority

Priority may distinguish definitions within the same scope.

Priority shall not be used to bypass reserved platform behavior.

Equal-priority unresolved matches constitute a conflict.

# 15. Conflict Detection

Conflicts shall be detected during:

- core registration;
- plugin registration;
- user customization;
- context activation where predicates overlap.

Conflict reports shall identify all competing definitions.

# 16. Conflict Resolution

Conflicts may be resolved by:

- scope specificity;
- explicit priority;
- disabling one binding;
- user reassignment;
- plugin fallback combination;
- rejecting registration.

Silent nondeterministic resolution is prohibited.

# 17. Core Shortcuts

Core shortcuts define essential application behavior, including:

- open;
- close;
- save or commit where applicable;
- search;
- command palette;
- navigation;
- tab management;
- Window management;
- copy, cut and paste;
- undo and redo;
- accessibility operations.

Core definitions shall follow macOS Human Interface conventions.

# 18. Editor Shortcuts

Editors may contribute scoped shortcuts.

Editor shortcuts shall:

- use stable editor capability identities;
- expose availability through projections;
- avoid overriding application-level conventions without explicit approval;
- translate state changes into Commands.

# 19. Plugin Shortcuts

Plugins may register shortcuts through the Plugin SDK.

Plugin registrations shall include:

- plugin identity;
- stable shortcut identity;
- default combination;
- allowed scopes;
- command identity;
- conflict fallback;
- user-customization policy.

Plugins shall not register directly with native Window objects.

# 20. Registration Lifecycle

Shortcut registration follows:

1. validate definition;
2. check reserved combinations;
3. check identity uniqueness;
4. detect static conflicts;
5. register in the logical shortcut registry;
6. publish updated keymap projection.

Unregistration shall remove plugin or feature bindings safely.

# 21. Shortcut Registry

The registry is the authoritative Desktop UI catalog of shortcut definitions.

It shall support:

- lookup by identity;
- lookup by key combination;
- lookup by command;
- scope filtering;
- source filtering;
- conflict analysis;
- user override application.

# 22. User Customization

Users may customize shortcuts when policy permits.

Customization supports:

- reassignment;
- removal;
- reset to default;
- import;
- export;
- profile selection.

Customization shall not modify immutable core defaults.

# 23. Keymaps

A keymap is a versioned collection of shortcut overrides.

Keymaps shall include:

- keymap identity;
- version;
- base profile;
- override entries;
- disabled entries;
- migration metadata.

# 24. Keymap Persistence

Keymap preferences shall be persisted through the appropriate configuration or user-preference service.

Views shall not write keymap files directly.

# 25. Keymap Migration

When shortcut identities or commands evolve, migration shall:

- preserve valid overrides;
- map renamed identities explicitly;
- report obsolete entries;
- avoid assigning new behavior silently to an old override.

# 26. International Keyboards

Shortcut definitions shall account for different keyboard layouts.

Each shortcut shall declare whether it is based on:

- semantic character;
- physical key position;
- platform symbolic key.

The policy shall be visible to customization UI.

# 27. Text Input Interaction

Shortcut processing shall not break:

- input method editors;
- dead keys;
- composed characters;
- dictation;
- native text editing conventions.

Text-input contexts may reserve key sequences that would otherwise match shortcuts.

# 28. Repeated Keys

Definitions shall declare whether repetition is allowed.

Repeated invocation is appropriate for actions such as navigation but inappropriate for destructive or modal commands unless explicitly designed.

# 29. Multi-Step Shortcuts

Chorded or multi-step shortcuts may be supported only when:

- timeout behavior is explicit;
- partial state is visible;
- cancellation is deterministic;
- accessibility remains usable;
- conflicts are detectable.

Single-step macOS-native shortcuts remain preferred.

# 30. Command Availability

A resolved shortcut shall dispatch only when the associated Command is currently available.

Unavailable shortcuts may:

- do nothing;
- produce native feedback;
- expose disabled status in discoverability surfaces.

They shall not dispatch invalid Commands.

# 31. Command Dispatch

Shortcut invocation shall create or select a Command with:

- active Workspace identity;
- active Window identity;
- logical target;
- invocation source;
- shortcut identity;
- correlation identity where required.

# 32. Discoverability

Shortcuts shall be exposed through:

- menu items;
- tooltips where appropriate;
- command palette;
- shortcut settings;
- contextual help;
- accessibility descriptions.

Display formatting shall use native macOS symbols.

# 33. Menu Integration

Menus consume the same logical shortcut registry.

Menu definitions shall not maintain separate independent shortcut bindings.

# 34. Accessibility

The shortcut system shall support:

- full keyboard navigation;
- VoiceOver discoverability;
- alternative access methods;
- customizable bindings;
- avoidance of inaccessible chord requirements;
- clear conflict reporting.

# 35. Security

Shortcuts that invoke sensitive actions may require additional validation or confirmation.

Plugins shall not bind privileged actions without declared capability approval.

# 36. Performance

Resolution shall be efficient enough for every key event.

The implementation should use indexed lookup by normalized key combination and active scope.

Context predicates shall be lightweight and side-effect free.

# 37. Diagnostics

Diagnostics shall expose:

- normalized key combination;
- active scopes;
- matching definitions;
- rejected candidates;
- selected shortcut identity;
- conflict reason;
- command identity;
- dispatch outcome;
- plugin source.

Sensitive text input shall not be logged as shortcut diagnostics.

# 38. Testing

Tests shall verify:

- scope precedence;
- reserved shortcut protection;
- conflict detection;
- user overrides;
- keymap migration;
- international layouts;
- text input coexistence;
- plugin registration;
- command availability;
- repeated key policy;
- discoverability consistency.

# 39. Architectural Invariants

The following invariants are mandatory:

- shortcut resolution is deterministic;
- system-reserved shortcuts are protected;
- bindings use stable identities;
- state-changing shortcuts dispatch Commands;
- context predicates are side-effect free;
- menu and shortcut systems share one registry;
- user overrides never mutate core defaults;
- unresolved conflicts are never activated silently;
- plugin shortcuts use Plugin SDK registration;
- text input and accessibility remain functional.

# 40. Related Documents

- `InputHandling.md`
- `CommandArchitecture.md`
- `ContextMenus.md`
- `Toolbar.md`
- `Accessibility.md`
- `PluginSDK/Capabilities.md`
- `Configuration.md`

# 41. Status

**Approved**

This document establishes the authoritative Keyboard Shortcut architecture for the KnowledgeOS Desktop Application.
