# Desktop Application Layout Projection

**Project:** KnowledgeOS

**Section:** Implementation

**Module:** Desktop Application

**Layer:** Desktop UI

**Version:** 1.0

**Status:** Approved

**Architecture Baseline:** KnowledgeOS Architecture V3

**Author:** KnowledgeOS Team

---


# 1. Purpose

This document defines the authoritative model that projects logical Workspace layout state into the native visual geometry of the KnowledgeOS Desktop Application.

Layout Projection preserves Workspace ownership while allowing each Window to adapt to native dimensions, display characteristics, accessibility settings and platform constraints.

# 2. Scope

This document governs:

- logical-to-visual layout transformation;
- Window geometry projection;
- split layouts;
- sidebars;
- inspectors;
- auxiliary panels;
- editor regions;
- floating regions;
- responsive adaptation;
- restoration;
- plugin layout participation.

# 3. Objectives

Layout Projection shall:

- preserve Workspace as the source of truth;
- produce deterministic geometry;
- adapt safely to Window size changes;
- support multi-window layouts;
- maintain minimum usable dimensions;
- support restoration and recovery;
- remain independent from business logic;
- support plugins through controlled insertion points.

# 4. Architectural Position

```text
Workspace Layout State
        |
        v
Layout Projection
        |
        v
Layout Model
        |
        v
Native Layout Engine
        |
        v
View Geometry
```

# 5. Ownership

Workspace owns logical layout state, including:

- region presence;
- region ordering;
- split relationships;
- relative sizes;
- collapsed state;
- selected tab;
- panel attachment;
- detached Window relationships.

Desktop UI owns only transient native geometry required to display that state.

# 6. Logical and Native Layout

Logical layout describes intent.

Native layout describes pixels and platform geometry.

Examples:

- logical: Sidebar visible with preferred width;
- native: Sidebar frame is 280 points wide;
- logical: Editor split ratio is 0.6;
- native: Primary editor receives 920 points;
- logical: Inspector collapsed;
- native: Inspector has no visible frame.

Native geometry shall not become authoritative Workspace state.

# 7. Projection Inputs

Layout Projection consumes:

- immutable Workspace layout projection;
- Window content size;
- display scale;
- safe areas;
- full-screen state;
- accessibility text scale;
- platform layout direction;
- plugin contributions;
- minimum component constraints.

# 8. Projection Output

The output is an immutable Layout Model containing:

- region identities;
- parent-child relationships;
- resolved visibility;
- resolved geometry;
- z-order;
- clipping boundaries;
- resize constraints;
- focus traversal order;
- accessibility order.

# 9. Composition Regions

The standard Window layout includes:

```text
Root
├── Title Bar
├── Toolbar
├── Content Region
│   ├── Sidebar
│   ├── Workspace Region
│   │   ├── Tab Container
│   │   └── Editor Layout
│   ├── Inspector
│   └── Auxiliary Panels
├── Status Bar
├── Overlay Layer
└── Dialog Layer
```

# 10. Deterministic Resolution

Given equal logical layout state and equal native constraints, projection shall produce equivalent geometry.

Resolution shall not depend on incidental View creation order.

# 11. Constraint Priority

When available space is insufficient, constraints are resolved in this order:

1. preserve active content usability;
2. preserve mandatory controls;
3. preserve accessibility requirements;
4. satisfy minimum editor dimensions;
5. reduce flexible regions;
6. collapse optional panels;
7. enable scrolling or overflow presentation;
8. apply recovery fallback.

# 12. Window Geometry

Window geometry includes:

- frame;
- content frame;
- minimum size;
- maximum size when applicable;
- display association;
- full-screen state;
- restoration position.

Logical Workspace state stores restorable intent, while the native layer validates it against currently available displays.

# 13. Display Changes

When displays are added, removed or reconfigured, projection shall:

- detect invalid Window placement;
- move inaccessible Windows into a visible display;
- preserve size where possible;
- respect safe areas;
- avoid permanent mutation until normalized state is committed through Workspace rules.

# 14. Sidebar Projection

Sidebar projection resolves:

- visibility;
- collapsed state;
- width;
- minimum and maximum width;
- selected section;
- plugin sections;
- compact presentation.

Sidebar width may be clamped to current Window constraints without destroying the stored preferred width.

# 15. Inspector Projection

Inspector projection resolves:

- visibility;
- attachment side;
- width;
- active section;
- contextual content;
- plugin sections;
- compact or overlay mode.

On constrained Windows, the Inspector may project as an overlay while preserving its logical role.

# 16. Workspace Region

The Workspace Region receives the remaining primary content geometry after mandatory chrome and visible side regions are resolved.

It contains the tab and editor layout projections.

# 17. Tab Layout

Tab projection resolves:

- tab bar visibility;
- active tab;
- pinned tabs;
- overflow behavior;
- drag targets;
- close controls;
- accessibility order.

Tab identity remains logical and independent from native tab controls.

# 18. Editor Layout

Editor layouts may include:

- single editor;
- horizontal split;
- vertical split;
- nested split;
- comparison view;
- preview arrangement.

Split trees shall remain acyclic and deterministic.

# 19. Split Ratios

Workspace may store normalized split ratios.

Projection converts ratios into native geometry while respecting:

- minimum child sizes;
- divider thickness;
- accessibility scaling;
- hidden children;
- plugin constraints.

Temporary clamping shall not overwrite the preferred ratio automatically.

# 20. Auxiliary Panels

Auxiliary Panels may be:

- docked;
- collapsed;
- overlaid;
- detached;
- hidden.

Their presentation depends on available geometry and logical attachment state.

# 21. Floating Regions

Floating regions are projected into native floating panels or child Windows when approved by Window Management rules.

Floating regions shall:

- retain stable logical identity;
- remain associated with one Workspace;
- preserve focus boundaries;
- validate placement against active displays.

# 22. Overlay Layer

The Overlay Layer contains temporary presentation elements such as:

- command palette;
- search overlay;
- transient inspectors;
- progress surfaces;
- drag indicators.

Overlays do not alter the persistent layout tree unless an explicit Command commits a change.

# 23. Dialog Layer

Dialogs are projected above the normal composition hierarchy.

Modal behavior shall be expressed explicitly and shall not be inferred only from z-order.

# 24. Responsive Adaptation

Responsive adaptation may:

- collapse optional regions;
- convert docked panels to overlays;
- reduce spacing;
- enable tab overflow;
- simplify toolbar presentation;
- preserve the active editor.

Responsive adaptation changes visual projection, not logical ownership.

# 25. Layout Direction

Projection shall support left-to-right and right-to-left layout where applicable.

Direction-aware geometry shall preserve semantic placement rather than blindly mirroring all content.

# 26. Accessibility Scaling

Layout Projection shall account for:

- increased text sizes;
- larger controls;
- reduced motion;
- increased contrast;
- keyboard-only navigation;
- VoiceOver reading order.

Accessibility requirements take precedence over cosmetic preferences.

# 27. Layout Persistence

Persistent layout state is owned by Workspace and Session Management.

The Desktop UI may report user-driven geometry changes through Commands.

Direct persistence from Views is prohibited.

# 28. Restoration

Restoration follows this order:

1. load logical Workspace layout;
2. validate identities;
3. reconstruct Window relationships;
4. inspect current display environment;
5. project safe native geometry;
6. attach Views;
7. restore selection and focus;
8. commit normalized corrections only when required.

# 29. Recovery

Invalid or incomplete layout state shall be recovered deterministically.

Recovery may:

- discard invalid child references;
- replace impossible split ratios;
- move inaccessible Windows;
- collapse unsupported plugin regions;
- fall back to the standard single-editor layout.

Recovery shall preserve user content.

# 30. User Resizing

Native resize gestures produce proposed layout changes.

The UI shall translate completed changes into Commands containing logical values such as:

- preferred width;
- split ratio;
- collapsed state;
- Window placement intent.

Continuous native geometry updates may remain transient until the gesture completes.

# 31. Plugins

Plugins may contribute layout regions only through declared extension points.

Plugin regions shall provide:

- stable identity;
- minimum dimensions;
- preferred dimensions;
- supported placements;
- collapse behavior;
- accessibility metadata.

Plugins shall not rewrite the core layout tree directly.

# 32. Layout Invalidations

Layout shall be recalculated when:

- Window size changes;
- region visibility changes;
- split structure changes;
- accessibility settings change;
- theme metrics change;
- plugin regions change;
- display configuration changes;
- content constraints change.

# 33. Performance

Projection should:

- avoid full-tree recalculation when unnecessary;
- cache immutable constraint results;
- update only affected subtrees;
- coalesce rapid resize events;
- prioritize visible geometry;
- avoid blocking the UI thread with expensive measurements.

# 34. Diagnostics

Diagnostics shall expose:

- logical layout revision;
- resolved Window size;
- active constraints;
- collapsed regions;
- split ratios;
- clamped values;
- recovery actions;
- projection duration;
- plugin constraints;
- invalidation reason.

# 35. Testing

Tests shall verify:

- deterministic projection;
- minimum-size enforcement;
- responsive adaptation;
- split geometry;
- multi-display restoration;
- inaccessible Window recovery;
- accessibility scaling;
- plugin region isolation;
- resize Command generation;
- right-to-left behavior where supported.

# 36. Architectural Invariants

The following invariants are mandatory:

- Workspace owns logical layout state;
- native geometry is a projection;
- equal inputs produce equivalent layout;
- the layout tree remains acyclic;
- active content remains usable;
- inaccessible Windows are recovered safely;
- temporary clamping does not silently destroy preferences;
- Views never persist layout directly;
- plugin regions use approved extension points;
- layout adaptation does not execute business logic.

# 37. Related Documents

- `ViewHierarchy.md`
- `ViewComposition.md`
- `RenderingPipeline.md`
- `WindowControllers.md`
- `WorkspaceRestoration.md`
- `Layout.md`
- `LayoutPersistence.md`
- `Accessibility.md`
- `ThemeSystem.md`

# 38. Status

**Approved**

This document establishes the authoritative Layout Projection model for the KnowledgeOS Desktop Application.
