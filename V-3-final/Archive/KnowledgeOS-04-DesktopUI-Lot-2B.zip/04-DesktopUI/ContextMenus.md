# Desktop Application Context Menus

**Project:** KnowledgeOS

**Section:** Implementation

**Module:** Desktop Application

**Layer:** Desktop UI

**Version:** 1.0

**Status:** Approved

---

# Purpose

Defines the architecture for contextual menus.

# Sections

- Context resolution
- Menu model
- Dynamic construction
- Command bindings
- Plugin contributions
- Accessibility
- Diagnostics
- Testing

# Core Rules

- Menus are projections.
- Menu actions dispatch Commands.
- Visibility depends on immutable projections.
- Plugins contribute only through SDK extension points.

# Invariants

- No business logic.
- Deterministic ordering.
- Stable menu identities.
- Context-sensitive availability.

**Approved**
