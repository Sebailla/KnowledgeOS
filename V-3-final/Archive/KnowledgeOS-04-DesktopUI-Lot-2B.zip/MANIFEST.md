# DesktopUI Lot 2B

Contains ContextMenus, DragAndDrop and Clipboard.
