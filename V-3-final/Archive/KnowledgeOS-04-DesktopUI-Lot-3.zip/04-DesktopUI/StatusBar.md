# StatusBar

**Project:** KnowledgeOS
**Section:** Implementation
**Module:** Desktop Application
**Layer:** Desktop UI
**Version:** 1.0
**Status:** Approved

---

# Purpose

Defines status bar architecture, progress indicators, background jobs, synchronization state, indexing state, AI status, plugin widgets and accessibility.

# Core Rules

- Presentation layer only.
- Immutable projections.
- Commands for state changes.
- Plugin SDK extension points only.
- Deterministic behavior.

# Invariants

- No business logic.
- Workspace remains authoritative.
- Native UI is a projection.

**Approved**
