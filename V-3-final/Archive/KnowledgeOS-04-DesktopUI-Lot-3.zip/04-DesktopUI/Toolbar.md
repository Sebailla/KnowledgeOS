# Toolbar

**Project:** KnowledgeOS
**Section:** Implementation
**Module:** Desktop Application
**Layer:** Desktop UI
**Version:** 1.0
**Status:** Approved

---

# Purpose

Defines toolbar architecture, action groups, contextual tools, command bindings, customization, plugin contributions, overflow behavior, accessibility and diagnostics. Toolbar is a projection of immutable Workspace state; actions dispatch Commands only.

# Core Rules

- Presentation layer only.
- Immutable projections.
- Commands for state changes.
- Plugin SDK extension points only.
- Deterministic behavior.

# Invariants

- No business logic.
- Workspace remains authoritative.
- Native UI is a projection.

**Approved**
