# Dialogs

**Project:** KnowledgeOS
**Section:** Implementation
**Module:** Desktop Application
**Layer:** Desktop UI
**Version:** 1.0
**Status:** Approved

---

# Purpose

Defines modal and modeless dialogs, lifecycle, validation, command confirmation, async workflows, plugin dialogs, accessibility and recovery.

# Core Rules

- Presentation layer only.
- Immutable projections.
- Commands for state changes.
- Plugin SDK extension points only.
- Deterministic behavior.

# Invariants

- No business logic.
- Workspace remains authoritative.
- Native UI is a projection.

**Approved**
