# Inspector

**Project:** KnowledgeOS
**Section:** Implementation
**Module:** Desktop Application
**Layer:** Desktop UI
**Version:** 1.0
**Status:** Approved

---

# Purpose

Defines contextual inspector architecture, property panels, semantic sections, plugin inspectors, editing workflow, validation, projection model and diagnostics.

# Core Rules

- Presentation layer only.
- Immutable projections.
- Commands for state changes.
- Plugin SDK extension points only.
- Deterministic behavior.

# Invariants

- No business logic.
- Workspace remains authoritative.
- Native UI is a projection.

**Approved**
