# Sidebar

**Project:** KnowledgeOS
**Section:** Implementation
**Module:** Desktop Application
**Layer:** Desktop UI
**Version:** 1.0
**Status:** Approved

---

# Purpose

Defines navigation sidebar architecture, tree projection, filtering, expansion state, virtualization, selection, plugin sections, accessibility and restoration. Sidebar never owns business state.

# Core Rules

- Presentation layer only.
- Immutable projections.
- Commands for state changes.
- Plugin SDK extension points only.
- Deterministic behavior.

# Invariants

- No business logic.
- Workspace remains authoritative.
- Native UI is a projection.

**Approved**
