# Public API Package

**Project:** KnowledgeOS  
**Section:** Integration / Public API  
**Document:** README  
**Version:** 4.0  
**Status:** Release Candidate  
**Author:** KnowledgeOS Team  

---

## 1. Purpose

Provide the authoritative entry point for KnowledgeOS public API transports and compatibility rules.

## 2. Package Structure

- `APIConventions.md`
- `Authentication.md`
- `Versioning.md`
- `REST.md`
- `GraphQL.md`
- `LocalAPI.md`

## 3. Invariants

- Public APIs MUST expose approved Platform contracts, not private repositories.
- Authentication and authorization MUST be enforced at every protected boundary.
- Transport models MUST NOT redefine Domain semantics.
- Retryable mutations MUST support idempotency.
- Breaking changes require a new major API version.
