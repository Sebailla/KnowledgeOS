# Plugin SDK Package

**Project:** KnowledgeOS  
**Section:** Integration / Plugin SDK  
**Document:** README  
**Version:** 4.0  
**Status:** Release Candidate  
**Author:** KnowledgeOS Team  

---

## 1. Purpose

Provide the authoritative entry point for the KnowledgeOS Plugin SDK integration package.

## 2. Package Structure

- `SDKArchitecture.md` — SDK boundary and dependency model.
- `Manifest.md` — plugin identity, version and declarations.
- `Capabilities.md` — least-privilege capability model.
- `Contracts.md` — public plugin-facing service contracts.
- `ExtensionPoints.md` — approved extension locations.
- `Compatibility.md` — SDK compatibility and migration.

## 3. Invariants

- Plugins MUST use public contracts only.
- Capabilities MUST be explicit and revocable.
- Extensions MUST be namespaced and versioned.
- Plugins MUST NOT redefine Domain identity, UDM, DPM or authority.
- Plugin failure MUST remain isolated from the host.

## 4. Reading Order

1. `SDKArchitecture.md`
2. `Manifest.md`
3. `Capabilities.md`
4. `Contracts.md`
5. `ExtensionPoints.md`
6. `Compatibility.md`
