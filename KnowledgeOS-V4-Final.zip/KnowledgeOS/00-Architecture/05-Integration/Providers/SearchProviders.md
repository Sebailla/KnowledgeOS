# Search Provider Contracts

**Project:** KnowledgeOS  
**Section:** Integration / Providers  
**Document:** SearchProviders  
**Version:** 4.0  
**Status:** Release Candidate  
**Author:** KnowledgeOS Team  

---

## 1. Purpose

Define provider contracts for local and remote search implementations used by Search Engine.

## 2. Scope

Providers may implement local full-text, vector, graph-assisted or Master Catalog search.

## 3. Requirements

- Providers MUST declare supported query and indexing capabilities.
- Results MUST preserve KnowledgeOS identities and authority scopes.
- Indexes MUST remain derived and rebuildable.
- Ranking MUST NOT redefine canonical meaning.
- Staleness and index version MUST be observable.
- Personal Knowledge MUST NOT be transmitted remotely without authorization.
- Provider failures MUST map to common error categories.

## 4. Invariants

- Providers are replaceable.
- Search results remain non-authoritative projections.
- Local and Master scopes remain distinct.
