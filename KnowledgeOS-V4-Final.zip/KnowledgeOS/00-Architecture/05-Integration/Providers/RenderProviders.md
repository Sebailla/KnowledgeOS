# Render Provider Contracts

**Project:** KnowledgeOS  
**Section:** Integration / Providers  
**Document:** RenderProviders  
**Version:** 4.0  
**Status:** Release Candidate  
**Author:** KnowledgeOS Team  

---

## 1. Purpose

Define provider contracts for renderer implementations used by Render Engine.

## 2. Scope

Providers may implement source-faithful rendering, reflow, preview, print and accessibility projections.

## 3. Requirements

- Providers MUST declare supported DPM purposes and output capabilities.
- Providers MUST preserve UDM/DPM identities and mappings.
- Renderer-specific objects MUST remain outside Platform contracts.
- Rendering MUST NOT mutate canonical UDM or DPM.
- Fidelity and fallback behavior MUST be explicit.
- Provider failures MUST map to common error categories.
- Render caches MUST remain rebuildable.

## 4. Invariants

- Providers are replaceable.
- Rendering is non-authoritative.
- Accessibility transformations preserve semantic reading order.
