# KnowledgeOS Architecture V4 — Final Release Candidate

This repository consolidates the complete Architecture V4 baseline.

## Included Architecture Sections

- 01-Foundation
- 02-Domain
- 03-Kernel
- 04-Platform
- 05-Integration
- 06-Execution
- 07-ArchitectureViews
- 08-Governance

## Frozen Decisions

- NAS Master Library is authoritative for catalog and source publications.
- Device Local Libraries are selective and independent.
- Local discovery scans user-authorized device locations.
- Publication acquisition is separate from synchronization.
- Personal Knowledge synchronizes among Apple Local Libraries through the approved iCloud/CloudKit profile.
- Personal Knowledge never enters the NAS Master Library.
- UDM and DPM are separate canonical models.
- Derived artifacts are rebuildable.

## Status

Architecture V4 is a final release candidate. Implementation may proceed against this baseline. Future breaking changes require governance review and an ADR.
