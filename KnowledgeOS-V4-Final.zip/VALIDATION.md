# Validation Report

- Documents validated: 9
- Total words: 1987
- Errors: 0
- Warnings: 2
- UTF-8: passed
- Architecture Views retained: yes
- Git metadata: excluded
- macOS metadata: excluded

## Warnings
- ArchitectureAmendment-v4.0-001.md: below 180 words
- ArchitectureFreeze-v4.0.md: below 180 words
