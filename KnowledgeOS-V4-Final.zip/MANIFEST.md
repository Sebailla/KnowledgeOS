# KnowledgeOS V4 — Governance Definitive Package

- Documents: 9
- Words: 1987
- Architecture Views retained
- AGENTS.md preserved
- Git/macOS metadata excluded

## Files

- `ArchitectureAmendment-v4.0-001.md`
- `ArchitectureBacklog.md`
- `ArchitectureDecisionMatrix.md`
- `ArchitectureFreeze-v4.0.md`
- `ArchitectureReview-v4.0.md`
- `ArchitectureV4MigrationPlan.md`
- `ArchitectureVocabulary.md`
- `DocumentationStandards.md`
- `README.md`
